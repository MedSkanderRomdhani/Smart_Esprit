#ifdef HAVE_CONFIG_H
#  include<config.h>
#endif



#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "fonction.h"
#include <gtk/gtk.h>
enum
{	
	ECIN,
	ENAME,
	ESURNAME,
	EADDRESS,
 	EPHONENUMBER,
	ELEVEL,
	EGENDER,
	EDESIREDBLOCK,
	COLUMNS,
};

void result(int choice[],char text[])
{
if(choice[0]==1)
strcpy(text,"homme");
if(choice[1]==1)
strcpy(text,"femme");
}

void add_student(student s){
FILE* f=NULL;
f=fopen("studentslist.txt","a+");

    fprintf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock);
fclose(f);
}
void viewcurrentinfo (char fname[],GtkWidget *liste)
{       FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
student s;
	


store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Name", renderer, "text", ENAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", ESURNAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("address", renderer, "text", EADDRESS, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("phonenumber", renderer, "text", EPHONENUMBER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("level", renderer, "text",ELEVEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("gender", renderer, "text",EGENDER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("desiredblock", renderer, "text",EDESIREDBLOCK, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);




}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen(fname,"r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen(fname,"a+");
	while (fscanf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock)!=EOF)
	
{ 

	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter ,s.ECIN,s.CIN,s.ENAME,s.Name,s.ESURNAME,s.Surname,s.EADDRESS,s.address,s.EPHONENUMBER,s.phonenumber,s.ELEVEL,s.level,s.EGENDER,s.gender,s.EDESIREDBLOCK,s.desiredblock, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
void delete_student(char CIN[40]){
FILE* f=NULL;
FILE*f1=NULL;
student s ;
f=fopen("studentslist.txt","r");
f1=fopen("newstudentlist.txt","w+");
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock)!=EOF){
if (strcmp(CIN,s.CIN)!=0 )
{fprintf(f1,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock);}
}
fclose(f);
fclose(f1);
remove("studentslist.txt");
rename("newstudentlist.txt","studentslist.txt");
}
void search_student(student s,char CIN[40])
{

	
        FILE *f;
	FILE *f1;
        f=fopen("studentslist.txt","r");
        f1=fopen("studentslist1.txt","w");
        if(f==NULL)
{return;}
else    {

 while (fscanf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock)!=EOF)
        {
                 if (strcmp (CIN, s.CIN)==0)

			{ fprintf(f1,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock);
}

       }

       }
                       fclose(f);
                       fclose(f1);

   }
void showsearchresult(GtkWidget *liste)

{      

char CIN[40];
char Name [40];
char Surname[40];
char address[40];
char phonenumber[40];
char level[40];
char gender[40];
char desiredblock[40];


 FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
student s;
store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Name", renderer, "text", ENAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", ESURNAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("address", renderer, "text", EADDRESS, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("phonenumber", renderer, "text", EPHONENUMBER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("level", renderer, "text",ELEVEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("gender", renderer, "text",EGENDER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("desiredblock", renderer, "text",EDESIREDBLOCK, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);




}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen("studentslist.txt","r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen("studentslist1.txt","a+");
	while (fscanf(f,"%s %s %s %s %s %s %s %s\n",CIN,Name,Surname,address,phonenumber,level,gender,desiredblock)!=EOF)
	
{ 

	gtk_list_store_append (store,&iter);
	gtk_list_store_set (store,&iter ,ECIN, CIN, ENAME, Name, ESURNAME, Surname,EADDRESS,address,EPHONENUMBER,phonenumber,ELEVEL,level,EGENDER,gender,EDESIREDBLOCK,desiredblock, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
void modify_student(student s1){
FILE* f=NULL;
FILE* f1=NULL;
student s;
f=fopen("studentslist.txt","r");
f1=fopen("modifiedstudentslist.txt","w+");
while(fscanf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock)!=EOF){
if (strcmp(s1.CIN,s.CIN)!=0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock);
}
else
{
fprintf(f1,"%s %s %s %s %s %s %s %s\n",s1.CIN,s1.Name,s1.Surname,s1.address,s1.phonenumber,s1.level,s1.gender,s1.desiredblock);
}

}
fclose(f);
fclose(f1);

remove("studentslist.txt");
rename("modifiedstudentslist.txt","studentslist.txt");
}





void level1list(student s)
{


   {

	char ch1[5]="1";
        FILE *f;
	FILE *f1;
        f=fopen("studentslist.txt","r");
        f1=fopen("niveau1.txt","w");
        if(f==NULL)
{return;}
else    {

 while (fscanf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock)!=EOF)
        {
                 if (strcmp (ch1, s.level)==0)

			{ fprintf(f1,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock);
}

       }

       }
                       fclose(f);
                       fclose(f1);

   }

   }


void shownumberstudentlevel1(char fname[],GtkWidget *liste)
{	FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	student s;
	
char CIN[40];
char Name [40];
char Surname[40];
char address[40];
char phonenumber[40];
char level[40];
char gender[40];
char desiredblock[40];

store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Name", renderer, "text", ENAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", ESURNAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("address", renderer, "text", EADDRESS, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("phonenumber", renderer, "text", EPHONENUMBER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("level", renderer, "text",ELEVEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("gender", renderer, "text",EGENDER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("desiredblock", renderer, "text",EDESIREDBLOCK, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);




}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen(fname,"r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen(fname,"a+");
	while (fscanf(f,"%s %s %s %s %s %s %s %s\n",CIN,Name,Surname,address,phonenumber,level,gender,desiredblock)!=EOF)
	
{ 

	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter ,ECIN,CIN,ENAME,Name,ESURNAME,Surname,EADDRESS,address,EPHONENUMBER,phonenumber,ELEVEL,level,EGENDER,gender,EDESIREDBLOCK,desiredblock, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}


void level2list(student s)
{

{

	char ch1[5]="2";
        FILE *f;
	FILE *f1;
        f=fopen("studentslist.txt","r");
        f1=fopen("niveau2.txt","w");
        if(f==NULL)
{return;}
else    {

 while (fscanf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock)!=EOF)
        {
                 if (strcmp (ch1, s.level)==0)

			{ fprintf(f1,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock);
}

       }

       }
                       fclose(f);
                       fclose(f1);

   }
   }


void shownumberstudentlevel2(char fname[],GtkWidget *liste)
{FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
char CIN[40];
char Name [40];
char Surname[40];
char address[40];
char phonenumber[40];
char level[40];
char gender[40];
char desiredblock[40];
student s;
store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Name", renderer, "text", ENAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", ESURNAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("address", renderer, "text", EADDRESS, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("phonenumber", renderer, "text", EPHONENUMBER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("level", renderer, "text",ELEVEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("gender", renderer, "text",EGENDER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("desiredblock", renderer, "text",EDESIREDBLOCK, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen(fname,"r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen(fname,"a+");
	while (fscanf(f,"%s %s %s %s %s %s %s %s\n",CIN,Name,Surname,address,phonenumber,level,gender,desiredblock)!=EOF)	
{ 
gtk_list_store_append (store,&iter);

	gtk_list_store_set (store,&iter ,ECIN, CIN, ENAME, Name, ESURNAME, Surname,EADDRESS,address,EPHONENUMBER,phonenumber,ELEVEL,level,EGENDER,gender,EDESIREDBLOCK,desiredblock, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}


void level3list(student s)
{

{

	char ch1[5]="3";
        FILE *f;
	FILE *f1;
        f=fopen("studentslist.txt","r");
        f1=fopen("niveau3.txt","w");
        if(f==NULL)
{return;}
else    {

 while (fscanf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock)!=EOF)
        {
                 if (strcmp (ch1, s.level)==0)

			{ fprintf(f1,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock);
}

       }

       }
                       fclose(f);
                       fclose(f1);

   }
   }


void shownumberstudentlevel3(char fname[],GtkWidget *liste)
{FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
char CIN[40];
char Name [40];
char Surname[40];
char address[40];
char phonenumber[40];
char level[40];
char gender[40];
char desiredblock[40];
student s;
store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Name", renderer, "text", ENAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", ESURNAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("address", renderer, "text", EADDRESS, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("phonenumber", renderer, "text", EPHONENUMBER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("level", renderer, "text",ELEVEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("gender", renderer, "text",EGENDER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("desiredblock", renderer, "text",EDESIREDBLOCK, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen(fname,"r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen(fname,"a+");
	while (fscanf(f,"%s %s %s %s %s %s %s %s\n",CIN,Name,Surname,address,phonenumber,level,gender,desiredblock)!=EOF)	
{ 
gtk_list_store_append (store,&iter);

	gtk_list_store_set (store,&iter ,ECIN, CIN, ENAME, Name, ESURNAME, Surname,EADDRESS,address,EPHONENUMBER,phonenumber,ELEVEL,level,EGENDER,gender,EDESIREDBLOCK,desiredblock, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

void level4list(student s)
{


  {

	char ch1[5]="4";
        FILE *f;
	FILE *f1;
        f=fopen("studentslist.txt","r");
        f1=fopen("niveau4.txt","w");
        if(f==NULL)
{return;}
else    {

 while (fscanf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock)!=EOF)
        {
                 if (strcmp (ch1, s.level)==0)

			{ fprintf(f1,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock);
}

       }

       }
                       fclose(f);
                       fclose(f1);

   }
   }


void shownumberstudentlevel4(char fname[],GtkWidget *liste)
{FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
char CIN[40];
char Name [40];
char Surname[40];
char address[40];
char phonenumber[40];
char level[40];
char gender[40];
char desiredblock[40];
student s;
store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Name", renderer, "text", ENAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", ESURNAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("address", renderer, "text", EADDRESS, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("phonenumber", renderer, "text", EPHONENUMBER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("level", renderer, "text",ELEVEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("gender", renderer, "text",EGENDER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("desiredblock", renderer, "text",EDESIREDBLOCK, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen(fname,"r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen(fname,"a+");
	while (fscanf(f,"%s %s %s %s %s %s %s %s\n",CIN,Name,Surname,address,phonenumber,level,gender,desiredblock)!=EOF)	
{ 
gtk_list_store_append (store,&iter);

	gtk_list_store_set (store,&iter ,ECIN, CIN, ENAME, Name, ESURNAME, Surname,EADDRESS,address,EPHONENUMBER,phonenumber,ELEVEL,level,EGENDER,gender,EDESIREDBLOCK,desiredblock, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}


void level5list(student s)
{


        {

	char ch1[5]="5";
        FILE *f;
	FILE *f1;
        f=fopen("studentslist.txt","r");
        f1=fopen("niveau5.txt","w");
        if(f==NULL)
{return;}
else    {

 while (fscanf(f,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock)!=EOF)
        {
                 if (strcmp (ch1, s.level)==0)

			{ fprintf(f1,"%s %s %s %s %s %s %s %s\n",s.CIN,s.Name,s.Surname,s.address,s.phonenumber,s.level,s.gender,s.desiredblock);
}

       }

       }
                       fclose(f);
                       fclose(f1);

   }
   }


void shownumberstudentlevel5(char fname[],GtkWidget *liste)
{FILE *f;
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
char CIN[40];
char Name [40];
char Surname[40];
char address[40];
char phonenumber[40];
char level[40];
char gender[40];
char desiredblock[40];
student s;
store=NULL;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Name", renderer, "text", ENAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("Surname", renderer, "text", ESURNAME, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("address", renderer, "text", EADDRESS, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("phonenumber", renderer, "text", EPHONENUMBER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("level", renderer, "text",ELEVEL, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("gender", renderer, "text",EGENDER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("desiredblock", renderer, "text",EDESIREDBLOCK, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

f=fopen(fname,"r");
if(f==NULL)
{
	return;
}
else
{
	f=fopen(fname,"a+");
	while (fscanf(f,"%s %s %s %s %s %s %s %s\n",CIN,Name,Surname,address,phonenumber,level,gender,desiredblock)!=EOF)	
{ 
gtk_list_store_append (store,&iter);

	gtk_list_store_set (store,&iter ,ECIN, CIN, ENAME, Name, ESURNAME, Surname,EADDRESS,address,EPHONENUMBER,phonenumber,ELEVEL,level,EGENDER,gender,EDESIREDBLOCK,desiredblock, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
