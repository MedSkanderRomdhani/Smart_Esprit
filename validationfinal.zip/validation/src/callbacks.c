#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

char block[20];
int choice[2]={0,0};

GtkWidget *entry18;
	GtkWidget *combobox2;
	GtkWidget *output;
	combobox1=lookup_widget(button,"combobox2");
	strcat(text,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));



void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{choice[0]=1;}
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{choice[1]=1;}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(block,"bloc1");}
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(block,"bloc2");}
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(block,"bloc3");}
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{strcpy(block,"bloc4");}
}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
char text[100]="";
char text1[100]="L'étudiant est ajouté avec succés";
char text2[40]="CIN Incorrect";
char text4[40]=" Veuillez-bien votre Numéro de telephone SVP !";
char text5[40]=" Champ Vide!";
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12,*output;
GtkWidget *window1;
student s;
window1=lookup_widget(button,"window1");


input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
input3=lookup_widget(button,"entry9");
input4=lookup_widget(button,"entry4");
input5=lookup_widget(button,"entry10");
input6=lookup_widget(button,"entry6");
input7=lookup_widget(button,"combobox2");
input8=lookup_widget(button,"radiobutton1");
input9=lookup_widget(button,"radiobutton2");
input10=lookup_widget(button,"radiobutton3");
input11=lookup_widget(button,"radiobutton4");
output=lookup_widget(button,"label12");
strcpy(s.CIN,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(s.Name,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(s.Surname,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(s.address,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(s.phonenumber,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(s.level,gtk_entry_get_text(GTK_ENTRY(input6)));
result(choice,text);
strcpy(s.gender,text);
strcpy(s.desiredblock,block);
if (strlen(s.CIN)==8 && strlen(s.phonenumber)==8)
{add_student(s);
gtk_label_set_text(GTK_LABEL(output),text1);}
else if (strlen(s.CIN)!=8 || s.CIN=="")
gtk_label_set_text(GTK_LABEL(output),text2);
else if(strlen(s.phonenumber)!=8 || s.phonenumber=="")
{gtk_label_set_text(GTK_LABEL(output),text4);}
else if ( s.Name=="")
gtk_label_set_text(GTK_LABEL(output),text5);
else if ( s.Surname=="")
gtk_label_set_text(GTK_LABEL(output),text5);
else if ( s.address=="")
gtk_label_set_text(GTK_LABEL(output),text5);
else if ( s.gender=="")
gtk_label_set_text(GTK_LABEL(output),text5);
else if ( s.desiredblock=="")
gtk_label_set_text(GTK_LABEL(output),text5);
else if ( s.level=="")
gtk_label_set_text(GTK_LABEL(output),text5);
}

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2 ;
	
	window2 =lookup_widget(button,"window2");
	window2 =create_window2();
	gtk_widget_show(window2);
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4 ;
	
	window4 =lookup_widget(button,"window4");
	window4 =create_window4();
	gtk_widget_show(window4);
}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window5;
	GtkWidget *treeview1;
window5=lookup_widget(button,"window5");
window5=create_window5();
gtk_widget_show(window5);
treeview1=lookup_widget(window5,"treeview1");
viewcurrentinfo("studentslist.txt",treeview1);
}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1 ;
	
	window1 =lookup_widget(button,"window1");
	window1 =create_window1();
	gtk_widget_show(window1);
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3 ;
	
	window3 =lookup_widget(button,"window4");
	window3 =create_window3();
	gtk_widget_show(window3);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7;
	GtkWidget *treeview3,*treeview5,*treeview6,*treeview7,*treeview8;
GtkWidget *window8;
student s;
window7=lookup_widget(button,"window7");
window7=create_window7();
gtk_widget_show(window7);
window8=lookup_widget(button,"window8");
window8=create_window8();
gtk_widget_show(window8);
treeview3=lookup_widget(window7,"treeview3");
treeview5=lookup_widget(window7,"treeview5");
treeview6=lookup_widget(window7,"treeview6");
treeview7=lookup_widget(window7,"treeview7");
treeview8=lookup_widget(window8,"treeview8");
level1list(s);
shownumberstudentlevel1("niveau1.txt",treeview3);
level2list(s);
shownumberstudentlevel2("niveau2.txt",treeview5);
level3list(s);
shownumberstudentlevel3("niveau3.txt",treeview6);
level4list(s);
shownumberstudentlevel4("niveau4.txt",treeview7);
level5list(s);
shownumberstudentlevel5("niveau5.txt",treeview8);
	
	
}


void
on_checkbutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{choice[0]=1;}
}


void
on_checkbutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
{choice[1]=1;}
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
char text[100]="";
char text1[100]="Modifiée avec succés";
char text2[40]="CIN incorrect";
char text4[40]=" veuillez-vous verfier votre N° de Télephone";
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*output;
GtkWidget *window2;
student s1;
int x;
window2=lookup_widget(button,"window2");


input1=lookup_widget(button,"entry11");
input2=lookup_widget(button,"entry12");
input3=lookup_widget(button,"entry13");
input4=lookup_widget(button,"entry14");
input5=lookup_widget(button,"entry15");
input6=lookup_widget(button,"entry16");
input7=lookup_widget(button,"checkbutton3");
input8=lookup_widget(button,"checkbutton4");
input8=lookup_widget(button,"spinbutton1");
output=lookup_widget(button,"label40");
strcpy(s1.CIN,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(s1.Name,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(s1.Surname,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(s1.address,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(s1.phonenumber,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(s1.level,gtk_entry_get_text(GTK_ENTRY(input6)));
result(choice,text);
strcpy(s1.gender,text);
x=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
sprintf(s1.desiredblock,"%d",x);
if (strlen(s1.CIN)==8 && strlen(s1.phonenumber)==8 && s1.Name!="" && s1.Surname!="" && s1.address!=""&& s1.gender!="" &&s1.desiredblock!="" && s1.level!="")
{modify_student(s1);
gtk_label_set_text(GTK_LABEL(output),text1);}
else if (strlen(s1.CIN)!=8 || s1.CIN=="")
gtk_label_set_text(GTK_LABEL(output),text2);
else if(strlen(s1.phonenumber)!=8 || s1.phonenumber=="")
{gtk_label_set_text(GTK_LABEL(output),text4);}



}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window2 ;
	
	window2 =lookup_widget(button,"window2");
	gtk_widget_destroy(window2);
	window1 =lookup_widget(button,"window1");	
	gtk_widget_show(window1);

}
void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window3 ;
	
	window3 =lookup_widget(button,"window3");
	gtk_widget_destroy(window3);
	window1 =lookup_widget(button,"window1");
	gtk_widget_show(window1);
}


void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char CIN[40];
char text[100]="Etudiant supprimé ! raison : ";
char text2[40]="CIN incorrect";
	
	GtkWidget *entry18;
	GtkWidget *combobox1;
	GtkWidget *output;
	combobox1=lookup_widget(button,"combobox1");
	strcat(text,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	entry18=lookup_widget(button,"entry18");
	strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(entry18)));
	output=lookup_widget(button,"label39");
	if (strlen(CIN)==8)
	{gtk_label_set_text(GTK_LABEL(output),text);
	delete_student(CIN);}
	else
	gtk_label_set_text(GTK_LABEL(output),text2);
}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
	GtkWidget *window6;
	GtkWidget *treeview2;
	GtkWidget *entry19;
	char CIN[40];
	student s;

	entry19=lookup_widget(button,"entry19");
	strcpy(CIN,gtk_entry_get_text(GTK_ENTRY(entry19)));
	
	search_student(s,CIN);
window6 =lookup_widget(button,"window6");	
	window6 =create_window6();
	gtk_widget_show(window6);
	treeview2=lookup_widget(window6 ,"treeview2");
	showsearchresult(treeview2);
	
	
}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window4 ;
	
	window4 =lookup_widget(button,"window4");
	gtk_widget_destroy(window4);
	window1 =lookup_widget(button,"window1");	
	gtk_widget_show(window1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gchar *CIN;
	gchar *Name;
	gchar *Surname;
	gchar *address;
	gchar *phonenumber;
	gchar *level;
	gchar *gender;
	gchar *desiredblock;
	student s;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&CIN,1,&Name,2,&Surname,3,&address,4,&phonenumber,5,&level,6,&gender,7,&desiredblock,-1);
	strcpy(s.CIN,CIN);
	strcpy(s.Name,Name);
	strcpy(s.Surname,Surname);
	strcpy(s.address,address);
	strcpy(s.phonenumber,phonenumber);
	strcpy(s.level,level);
	strcpy(s.gender,gender);
	strcpy(s.desiredblock,desiredblock);
	delete_student(CIN);
	viewcurrentinfo ("studentslist.txt",treeview);}

}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window5 ;
	
	window5 =lookup_widget(button,"window5");
	gtk_widget_destroy(window5);
	window1 =lookup_widget(button,"window1");	
	gtk_widget_show(window1);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	
	gchar *CIN;
	gchar *Name;
	gchar *Surname;
	gchar *address;
	gchar *phonenumber;
	gchar *level;
	gchar *gender;
	gchar *desiredblock;
	GtkTreeIter iter;	
	student s;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&CIN,1,&Name,2,&Surname,3,&address,4,&phonenumber,5,&level,6,&gender,7,&desiredblock,-1);
	
	
	showsearchresult(treeview);}
}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window6 ;
	
	window6 =lookup_widget(button,"window6");
	gtk_widget_destroy(window6);
	window1 =lookup_widget(button,"window1");	
	gtk_widget_show(window1);
}


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *CIN;
	gchar *Name;
	gchar *Surname;
	gchar *address;
	gchar *phonenumber;
	gchar *level;
	gchar *gender;
	gchar *desiredblock;
	student s;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&CIN,1,&Name,2,&Surname,3,&address,4,&phonenumber,5,&level,6,&gender,7,&desiredblock,-1);
	strcpy(s.CIN,CIN);
	strcpy(s.Name,Name);
	strcpy(s.Surname,Surname);
	strcpy(s.address,address);
	strcpy(s.phonenumber,phonenumber);
	strcpy(s.level,level);
	strcpy(s.gender,gender);
	strcpy(s.desiredblock,desiredblock);
	level1list(s);
	shownumberstudentlevel1("niveau1.txt",treeview);}
	
}


void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

	
}


void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *CIN;
	gchar *Name;
	gchar *Surname;
	gchar *address;
	gchar *phonenumber;
	gchar *level;
	gchar *gender;
	gchar *desiredblock;
	student s;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&CIN,1,&Name,2,&Surname,3,&address,4,&phonenumber,5,&level,6,&gender,7,&desiredblock,-1);
	strcpy(s.CIN,CIN);
	strcpy(s.Name,Name);
	strcpy(s.Surname,Surname);
	strcpy(s.address,address);
	strcpy(s.phonenumber,phonenumber);
	strcpy(s.level,level);
	strcpy(s.gender,gender);
	strcpy(s.desiredblock,desiredblock);
	level2list(s);
	shownumberstudentlevel2("niveau2.txt",treeview);}
	
}


void
on_treeview6_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *CIN;
	gchar *Name;
	gchar *Surname;
	gchar *address;
	gchar *phonenumber;
	gchar *level;
	gchar *gender;
	gchar *desiredblock;
	student s;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&CIN,1,&Name,2,&Surname,3,&address,4,&phonenumber,5,&level,6,&gender,7,&desiredblock,-1);
	strcpy(s.CIN,CIN);
	strcpy(s.Name,Name);
	strcpy(s.Surname,Surname);
	strcpy(s.address,address);
	strcpy(s.phonenumber,phonenumber);
	strcpy(s.level,level);
	strcpy(s.gender,gender);
	strcpy(s.desiredblock,desiredblock);
	level3list(s);
	shownumberstudentlevel3("niveau3.txt",treeview);}
	
}


void
on_treeview7_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *CIN;
	gchar *Name;
	gchar *Surname;
	gchar *address;
	gchar *phonenumber;
	gchar *level;
	gchar *gender;
	gchar *desiredblock;
	student s;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&CIN,1,&Name,2,&Surname,3,&address,4,&phonenumber,5,&level,6,&gender,7,&desiredblock,-1);
	strcpy(s.CIN,CIN);
	strcpy(s.Name,Name);
	strcpy(s.Surname,Surname);
	strcpy(s.address,address);
	strcpy(s.phonenumber,phonenumber);
	strcpy(s.level,level);
	strcpy(s.gender,gender);
	strcpy(s.desiredblock,desiredblock);
	level4list(s);
	shownumberstudentlevel4("niveau4.txt",treeview);}
	
}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window7 ;
	
	window7 =lookup_widget(button,"window7");
	gtk_widget_destroy(window7);
	window1 =lookup_widget(button,"window1");	
	gtk_widget_show(window1);
}
void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window8 ;
	
	window8 =lookup_widget(button,"window8");
	gtk_widget_destroy(window8);
	window1 =lookup_widget(button,"window1");	
	gtk_widget_show(window1);

}

void
on_treeview8_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar *CIN;
	gchar *Name;
	gchar *Surname;
	gchar *address;
	gchar *phonenumber;
	gchar *level;
	gchar *gender;
	gchar *desiredblock;
	student s;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&CIN,1,&Name,2,&Surname,3,&address,4,&phonenumber,5,&level,6,&gender,7,&desiredblock,-1);
	strcpy(s.CIN,CIN);
	strcpy(s.Name,Name);
	strcpy(s.Surname,Surname);
	strcpy(s.address,address);
	strcpy(s.phonenumber,phonenumber);
	strcpy(s.level,level);
	strcpy(s.gender,gender);
	strcpy(s.desiredblock,desiredblock);
	level5list(s);
	shownumberstudentlevel5("niveau5.txt",treeview);}

}

