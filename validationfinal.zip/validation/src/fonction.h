#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <gtk/gtk.h>


typedef struct{
char CIN[40];
char Name [40];
char Surname[40];
char address[40];
char phonenumber[40];
char level[40];
char gender[40];
char desiredblock[40];
}student;
void result(int choice[],char text[]);
void add_student(student s);
void viewcurrentinfo (char fname[],GtkWidget *liste);
void delete_student(char CIN[40]);
void showsearchresult(GtkWidget *liste);
void search_student(student s,char CIN[40]);
void modify_student(student s1);


// part two functions:
void level1list(student s);
void shownumberstudentlevel1(char fname[],GtkWidget *liste);
void level2list(student s);
void shownumberstudentlevel2(char fname[],GtkWidget *liste);
void level3list(student s);
void shownumberstudentlevel3(char fname[],GtkWidget *liste);
void level4list(student s);
void shownumberstudentlevel4(char fname[],GtkWidget *liste);
void level5list(student s);
void shownumberstudentlevel5(char fname[],GtkWidget *liste);
