#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <gtk/gtk.h>


typedef struct{
int CIN;
char Name [20];
char Surname[40];
char address[20];
int phonenumber;
int level;
char gender[20];
int desiredblock;
}student;


void add_student(student s);
void viewcurrentinfo (GtkWidget *liste);
void delete_student(int CIN);
