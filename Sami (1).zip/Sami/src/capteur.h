#include<gtk/gtk.h>

typedef struct
{char id[20];
int valeur;
char type[20]; //température ,humidité
}Capteur;

void ajouter_capteur(Capteur C);
void supprimer(char id1[]);
void modifier(char id1[],int valeur1);
void afficher (GtkTreeView *liste);
void alerte ();
void afficheralerte (GtkTreeView *liste);
