#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "capteur.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"

char idg[50];
void
on_buttonsupprim_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f ; 
GtkWidget *Home ,*idd ,*Next ,*treeview ;

char id[50] ; 

idd=lookup_widget(objet_graphique,"entryid");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idd)));

supprimer(id);

Home=lookup_widget(objet_graphique,"welc");
Next=create_welc(); 
gtk_widget_show(Next);
gtk_widget_hide(Home);
treeview=lookup_widget(Next,"treeview1");
afficher(treeview) ;
}

void
on_buttonajout_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *interf,*Home ;
Home=lookup_widget(objet_graphique,"welc");
interf=create_ajout();
gtk_widget_show(interf);
gtk_widget_hide(Home);
}


void
on_buttonretajout_clicked              (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *interf,*Home, *treeview ;
Home=lookup_widget(objet_graphique,"ajout");
interf=create_welc();
gtk_widget_show(interf);
gtk_widget_hide(Home);
treeview=lookup_widget(interf,"treeview1");
afficher(treeview) ;
}


void
on_buttonajouter_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *valeurr ,*typpe ,*idd,*interf,*Home,*treeview ;

Capteur c;


idd=lookup_widget(objet_graphique,"entry2");
typpe=lookup_widget(objet_graphique,"comboboxentry1");
valeurr=lookup_widget(objet_graphique,"spinbutton2");

strcpy(c.id,gtk_entry_get_text(GTK_ENTRY(idd)));
strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(typpe)));
c.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(valeurr));

ajouter_capteur(c);

Home=lookup_widget(objet_graphique,"ajout");
interf=create_welc();
gtk_widget_show(interf);
gtk_widget_hide(Home);
treeview=lookup_widget(interf,"treeview1");
afficher(treeview) ;
}


void
on_buttonmodif_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f ; 
GtkWidget *Home ,*Next ,*val ,*treeview ;
int valeur;

val=lookup_widget(objet_graphique,"spinbutton1");
valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val));

modifier(idg,valeur);

Home=lookup_widget(objet_graphique,"modif");
Next=create_welc(); 
gtk_widget_show(Next);
gtk_widget_hide(Home);
treeview=lookup_widget(Next,"treeview1");
afficher(treeview) ;
}


void
on_buttontomodif_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *interf,*Home,*idd ;
idd=lookup_widget(objet_graphique,"entryid");
strcpy(idg,gtk_entry_get_text(GTK_ENTRY(idd)));
Home=lookup_widget(objet_graphique,"welc");
interf=create_modif();
gtk_widget_show(interf);
gtk_widget_hide(Home);
}


void
on_buttonretmodif_clicked              (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *interf,*Home, *treeview ;
Home=lookup_widget(objet_graphique,"modif");
interf=create_welc();
gtk_widget_show(interf);
gtk_widget_hide(Home);
treeview=lookup_widget(interf,"treeview1");
afficher(treeview) ;
}


void
on_buttonalerte_clicked                (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *interf,*Home, *treeview ;
Home=lookup_widget(objet_graphique,"welc");
interf=create_alerte();
gtk_widget_show(interf);
gtk_widget_hide(Home);
alerte();
treeview=lookup_widget(interf,"treeview2");
afficheralerte(treeview) ;
}


void
on_buttonretalerte_clicked             (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *interf,*Home, *treeview ;
Home=lookup_widget(objet_graphique,"alerte");
interf=create_welc();
gtk_widget_show(interf);
gtk_widget_hide(Home);
treeview=lookup_widget(interf,"treeview1");
afficher(treeview) ;
}

