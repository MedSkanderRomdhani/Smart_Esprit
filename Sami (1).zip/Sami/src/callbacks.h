#include <gtk/gtk.h>


void
on_buttonsupprim_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajout_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretajout_clicked              (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajouter_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttontomodif_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretmodif_clicked              (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonalerte_clicked                (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretalerte_clicked             (GtkButton       *objet_graphique,
                                        gpointer         user_data);
