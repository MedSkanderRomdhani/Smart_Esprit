#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "capteur.h"

void ajouter_capteur(Capteur C)
{
FILE *f=NULL;
f=fopen("capteurs.txt","a");
if(f == NULL)
{
printf("Impossible d'ouvrir le fichier");
}
else
{
fprintf(f,"%s %s %d \n",C.id,C.type,C.valeur);
}
fclose(f);

}

void supprimer(char id1[])
{
FILE *f;
FILE *f1;
int r;
char id[50]; 
int valeur;
char type[50]; 



f=fopen("capteurs.txt","r");
f1=fopen("capteurs1.txt","w");
if (f!=NULL){
    if(f1!=NULL){
while(fscanf(f,"%s %s %d \n",id,type,&valeur)!=EOF ) {
    if(strcmp(id1,id)!=0)  
    {
        fprintf(f1,"%s %s %d \n",id,type,valeur);
        r=1;
    }
}
    }
    fclose(f1);
}

fclose(f);
if (r){
	remove ("capteurs.txt");
	rename ("capteurs1.txt","capteurs.txt");
	}

}



void modifier(char id1[],int valeur1)
{
FILE *f;
FILE *f1;
 
int r;
char id[50]; 
int valeur;
char type[50]; 

f=fopen("capteurs.txt","r");
f1=fopen("capteurs1.txt","w");
if (f!=NULL)
{
    if(f1!=NULL)
     {
while(fscanf(f,"%s %s %d \n",id,type,&valeur)!=EOF  ) 
{
    if(strcmp(id1,id)==0)  
            {
        fprintf(f1,"%s %s %d \n",id,type,valeur1);
            }
     else 
          {fprintf(f1,"%s %s %d \n",id,type,valeur);} 
}
}
}
fclose(f1);
fclose(f);

	remove ("capteurs.txt");
	rename ("capteurs1.txt","capteurs.txt");
	
}


enum 
{
ID ,
TYPE,
VALEUR, 
COLUMNS1
}; 


void afficher (GtkTreeView *liste)
{
GtkCellRenderer *render ;
GtkTreeViewColumn *column ; 
GtkTreeIter iter ; 

GtkListStore *store ;

char id[50]; 
int valeur;
char type[50]; 
store=NULL ; 
FILE* f ; 

store=gtk_tree_view_get_model(liste) ; 
if (store==NULL) 
{
render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("id",render,"text",ID,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("type",render,"text",TYPE,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("valeur",render,"text",VALEUR,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 



store=gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT) ; 

f=fopen("capteurs.txt","r") ; 
if (f==NULL) 
{
return ; 
}
else 
{
f=fopen("capteurs.txt","a+") ;
 while(fscanf(f,"%s %s %d \n",id,type,&valeur)!=EOF) 
{
gtk_list_store_append (store,&iter) ; 
gtk_list_store_set (store,&iter,ID,id,TYPE,type,VALEUR,valeur,-1) ; 
}
fclose(f) ; }
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store)); 
g_object_unref (store) ; 

}
}

void alerte ()
{char id[50];
char type[50];
int valeur;
FILE *f;
FILE *f1;
f=fopen("capteurs.txt","r");
f1=fopen("alerte.txt","w");
if(f!=NULL)
{if(f1!=NULL)
{while(fscanf(f,"%s %s %d \n",id,type,&valeur)!=EOF) 
{
    if ((valeur>=200) && (valeur<=300))
	{
	fprintf(f1,"%s %s %d \n",id,type,valeur);
	}

}
fclose(f1);
fclose(f);
}
}
}

enum 
{
ID2 ,
TYPE2,
VALEUR2, 
COLUMNS2
}; 


void afficheralerte (GtkTreeView *liste)
{
GtkCellRenderer *render ;
GtkTreeViewColumn *column ; 
GtkTreeIter iter ; 

GtkListStore *store ;

char id[50]; 
int valeur;
char type[50]; 
store=NULL ; 
FILE* f ; 

store=gtk_tree_view_get_model(liste) ; 
if (store==NULL) 
{
render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("id",render,"text",ID2,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 


render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("type",render,"text",TYPE2,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 

render=gtk_cell_renderer_text_new () ; 
column =gtk_tree_view_column_new_with_attributes("valeur",render,"text",VALEUR2,NULL) ; 
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column); 



store=gtk_list_store_new(COLUMNS2,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT) ; 

f=fopen("alerte.txt","r") ; 
if (f==NULL) 
{
return ; 
}
else 
{
f=fopen("alerte.txt","a+") ;
 while(fscanf(f,"%s %s %d \n",id,type,&valeur)!=EOF) 
{
gtk_list_store_append (store,&iter) ; 
gtk_list_store_set (store,&iter,ID2,id,TYPE2,type,VALEUR2,valeur,-1) ; 
}
fclose(f) ; }
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store)); 
g_object_unref (store) ; 

}
}


